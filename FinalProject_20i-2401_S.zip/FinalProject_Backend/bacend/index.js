const mongoose = require('mongoose');	
const express = require('express');
const cors = require('cors');
const userRouter = require('./routes/UserRoutes')
const ReviewRouter = require('./routes/ReviewRouter')
const ActivityRouter = require('./routes/ActivityRouter')

require('dotenv').config();

const app = express();

app.use(express.json());
app.use(cors());

app.use('/user',userRouter);
app.use('/review',ReviewRouter);
 app.use('/activity', ActivityRouter)

app.get('/', (req, res) => 
{
    res.send('This is WEB Engineering Exam!')   
})

app.listen(process.env.PORT||3000, ()=>{
    console.log(`App listening at port ${process.env.PORT}`)
})
 mongoose.set('strictQuery', false);
 mongoose.connect(process.env.MONGO_URL)
 .then(() => {
   console.log("Connected to MongoDB Atlas");
 })
 .catch((error) => {
   console.log("Error connecting to MongoDB Atlas: ");
 });















