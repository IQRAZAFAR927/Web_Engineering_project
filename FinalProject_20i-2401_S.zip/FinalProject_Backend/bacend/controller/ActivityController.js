const Activity= require('../models/ActivityModel.js')
// const User= require('../models/UserModel.js')
const jwt = require('jsonwebtoken')


const AddActivity= (req, res) => 
{
  console.log("Execute the Add Activity Function");
  const { name, description,location,price,image} = req.body;
  Activity.findOne({ name: name}).then((activity) => 
  {
    if (activity)
    {
      res.status(400).send({ message: 'Activity already exists' });
      return;
    }
    const newActivity = new Activity({
      name: name,
      description: description,
      location: location,
      price: price,
      image:image
    });
    console.log(newActivity)
    newActivity.save().then((Activity) =>
     {
        res.status(200).send({
          message: 'Successfully added review',
          Activity: Activity,
        });
      })
     
      .catch((err) =>
        res.status(400).send({ message: 'Error adding review', error: err })
      );
  });
}


const updateActivity = async (req, res) => {
  console.log("Execuate the UpdateActivity Function")
  const { id } = req.params;
  console.log(id);

  const newActivity = {
    name: req.body.name,
    description: req.body.description,
    location: req.body.location,
    price: req.body.price,
    image: req.body.image
  };
  // console.log(req.body);
  try {
    const Updateactivity= await Activity.findByIdAndUpdate(id, newActivity);
    // const updatedActivity = await Activity.findBynameandUpdate(id, newUser);
    res.json({ message: "Activity Updated", Activity: Updateactivity });
    console.log("Activity Updated with this Information",Updateactivity);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error updating Activity" });
  }
};


const deleteActivity = async (req, res) => {
  console.log("Execute the DeleteActivity Function");
  const { id } = req.params;
  try {
    const deletedActivity = await Activity.findByIdAndDelete(id);
    if (!deletedActivity) {
      return res.status(404).json({ message: 'Activity not found' });
    }
    res.json({ message: 'Activity deleted successfully', deleteActivity: deletedActivity });
    console.log("Activity Delete with information:",deletedActivity);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error deleting Activity' });
  }
};

const getAllActivity = async (req, res) => {
  try {
    const activity = await Activity.find();
    res.json(activity);
    console.log(activity);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error getting activities" });
  }
}

  const getOneActivity = async (req, res) => {
    const { id} = req.params;  
    try {
    const activity= await Activity.findById(id);
     
      if (!activity) {
        return res.status(404).json({ message: 'Activity not found' });
      }
      res.json(activity);
      console.log("\nGetting one Activity Information:",activity);
    } catch (error) {
      res.status(500).json({ message: 'Error getting Activity' });
    }
  };

  // module.export= { AddActivity,getOneActivity , deleteActivity, updateActivity, getAllActivity};
  exports.AddActivity= AddActivity;
  exports.getOneActivity= getOneActivity;
  exports.deleteActivity=deleteActivity;
  exports.updateActivity=updateActivity;
  exports.getAllActivity=getAllActivity;
