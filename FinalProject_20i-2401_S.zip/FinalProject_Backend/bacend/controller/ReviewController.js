const Review = require('../models/ReviewModel.js')
// const User= require('../models/UserModel.js')
const jwt = require('jsonwebtoken')


const AddReview = (req, res) => 
{
  console.log("Execute the Add review Function");
  const { name, email, comment, rating} = req.body;

    const newReview = new Review({
      name: name,
      email: email,
      comment: comment,
      rating: rating,
    });
    console.log(newReview);
    newReview.save().then((review) => {
        res.status(200).send({
          message: 'Successfully added review',
          review: review,
        });
      })
      .catch((err) =>
        res.status(400).send({ message: 'Error adding review', error: err })
      );
};



  const getOneReview = async (req, res) => {
    const { id } = req.params;  
    try {
      const review = await Review.findById(id);
      if (!review) {
        return res.status(404).json({ message: 'Review not found' });
      }
      res.json(review);
      console.log("\nGetting one Review Information:",review);
    } catch (error) {
      res.status(500).json({ message: 'Error getting Review' });
    }
  };

  exports.AddReview=AddReview;
  // module.export= { AddReview }
  