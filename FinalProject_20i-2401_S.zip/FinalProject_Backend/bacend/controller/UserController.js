const User = require('../models/UserModel.js')
const jwt = require('jsonwebtoken')
// const Quiz = require('../models/ActivityModel.js')



const signup = (req, res) => {
    console.log("Execute the Signup");
    const { name, email, password, role} = req.body;
    User.findOne({ email: email }).then((user) => {
      if (user) {
        res.status(400).send({ message: 'User already exists' });
        return;
      }
  
      const newUser = new User({
        name: name,
        email: email,
        password: password,
        role: role,
      });
        // Generate a token for the new user
      // const token = jwt.sign({ userId: newUser._id }, process.env.SECRET_KEY);
      newUser
        .save()
        .then((user) => {
          res.status(200).send({
            message: 'Successfully added user',
            user: user,
            // token: token, // Include the generated token in the response
          });
        })
        .catch((err) =>
          res.status(400).send({ message: 'Error adding user', error: err })
        );
    });
  };
  

const login = (req,res)=>{
    console.log("Execute the Login")
    const {email, password} = req.body;
    User.findOne({email:email}).then((user)=>{
        if(user){
            if(user.password==password){
                const token = jwt.sign({id:user._id,role:user.role},process.env.SECRET_KEY,{expiresIn:'24h'})
                res.status(200).send({message:'Successfully logged in',user:user,token:token})
            }else{
                res.status(400).send({message:'Invalid credentials'})
            }
        }else{
            res.status(400).send({message:'Invalid credentials'})
        }
    }).catch((err)=>{res.status(400).send({message:'Error logging in',error:err})})
}


// const createQuiz = (req,res)=>{
//     const {topic,questions,answers,options,marks} = req.body
//     const newQuiz = new Quiz({
//         topic:topic,
//         questions:questions,
//         answers:answers,
//         options:options,
//         marks:marks
//     })
//     newQuiz.save().then((quiz)=>{
//         res.status(200).send({message:'Successfully created quiz',quiz:quiz})
//     }).catch((err)=>{res.status(400).send({message:'Error creating quiz',error:err})})
// }

// const updateMakrs = (req,res)=>{
//     const {name, email, password, role, marks} = req.body;
//     User.findOneAndUpdate({_id:req.user._id},{name:name, email:email, password:password, role:role, marks:marks}).then((user)=>{
//         res.status(200).send({message:'Successfully updated profile',user:user})
//     }).catch((err)=>{res.status(400).send({message:'Error updating profile',error:err})})
// }



// const getQuiz = (req,res)=>{
//     Quiz.find().then((quiz)=>{
//         res.status(200).send({message:'Successfully fetched quiz',quiz:quiz})
//     }).catch((err)=>{res.status(400).send({message:'Error fetching quiz',error:err})})
// }




// const leaderboard = (req, res) => {
//     User.find({ marks: { $ne: null } }) // Find users with non-null marks
//       .sort({ marks: 1 }) // Sort users by marks in ascending order
//       .then((users) => {
//         res.status(200).send({ message: 'Successfully fetched leaderboard', users: users });
//       })
//       .catch((err) => {
//         res.status(400).send({ message: 'Error fetching leaderboard', error: err });
//       });
//   };
  
  const updateuser = async (req, res) => {
    console.log("Execuate the UpdateUser Function")
    const { id } = req.params;
    console.log(id);
    const newUser = {
      name: req.body.name,
      email: req.body.email,
      password: req.body.password,
      role: req.body.role,
    };
    // console.log(req.body);
    try {
      const updatedUser = await User.findByIdAndUpdate(id, newUser);
      res.json({ message: "Profile Updated", user: updatedUser });
      console.log("Customer Updated with this Information",updatedUser);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Error updating user" });
    }
  };
  
  const deleteuser = async (req, res) => {
    console.log("Execute the DeleteUser Function");
    const { id } = req.params;
    try {
      const deletedUser = await User.findByIdAndDelete(id);
      if (!deletedUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json({ message: 'User deleted successfully', user: deletedUser });
      console.log("Customer Delete with information:",deletedUser);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Error deleting user' });
    }
  };
  
  const getAllCustomers = async (req, res) => {
    try {
      const users = await User.find();
      res.json(users);
      console.log(users);
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Error getting users" });
    }
  }

const getOneCustomer = async (req, res) => {
    const { id } = req.params;  
    try {
      const user = await User.findById(id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
      console.log("\nGetting one Customer Information:",user);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error getting user' });
    }
  };
  
 

module.exports = {login,signup,updateuser,deleteuser,getAllCustomers,getOneCustomer}

