const ActivityRouter = require('express').Router();

const jwt = require('jsonwebtoken')
var path = require('path')

const { AddActivity,getOneActivity , deleteActivity, updateActivity, getAllActivity } = require('../controller/ActivityController')



const login = (req,res)=>{
    console.log("Execute the Login")
    const {email, password} = req.body;
    User.findOne({email:email}).then((user)=>{
        if(user){
            if(user.password==password){
                const token = jwt.sign({id:user._id,role:user.role},process.env.SECRET_KEY,{expiresIn:'24h'})
                res.status(200).send({message:'Successfully logged in',user:user,token:token})
            }else{
                res.status(400).send({message:'Invalid credentials'})
            }
        }else{
            res.status(400).send({message:'Invalid credentials'})
        }
    }).catch((err)=>{res.status(400).send({message:'Error logging in',error:err})})
}



const verifyToken = (req,res,next)=>{
    // const {token} = req.headers
    const token = req.headers['token']
    if(token){
        jwt.verify(token,process.env.SECRET_KEY,(err,decoded)=>{
            if(err){
                res.status(400).send({message:'Invalid token',error:err})
            }else{
                req.decoded = decoded
                next()
            }
        })
    }else{
        res.status(400).send({message:'Invalid token'})
    }
}


const verifyUser = (req,res,next)=>{
    console.log("Execute the Verifyuser function");
    if(req.decoded.role=="user"){
        next()
    }else{
        res.status(400).send({message:'Unauthorized'})
    }
}

ActivityRouter.post('/addactivity',verifyToken,AddActivity)
ActivityRouter.get('/getoneActivity/:id', verifyToken,getOneActivity)
ActivityRouter.post('/delete/:id',deleteActivity)
ActivityRouter.post('/update/:id',updateActivity)
ActivityRouter.get('/getActivity',getAllActivity)


// userRouter.get('/oneCustomer/:id',getOneCustomer)
// userRouter.get('/getCustomers',getAllCustomers)
// userRouter.post('/delete/:id',deleteuser)
// userRouter.post('/update/:id',updateuser)
// userRouter.post('/signup',signup)
// userRouter.post('/login',verifyToken,login)



module.exports= ActivityRouter;