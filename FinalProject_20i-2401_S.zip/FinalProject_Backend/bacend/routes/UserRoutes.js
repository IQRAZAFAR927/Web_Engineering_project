const userRouter = require('express').Router();
const jwt = require('jsonwebtoken')
var path = require('path')
const {login,signup,updateuser,deleteuser,getAllCustomers,getOneCustomer } = require('../controller/UserController')


const verifyToken = (req,res,next)=>{
    // const {token} = req.headers
    const token = req.headers['token']
    if(token){
        jwt.verify(token,process.env.SECRET_KEY,(err,decoded)=>{
            if(err){
                res.status(400).send({message:'Invalid token',error:err})
            }else{
                req.decoded = decoded
                next()
            }
        })
    }else{
        res.status(400).send({message:'Invalid token'})
    }
}

const verifyUser = (req,res,next)=>{
    console.log("Execute the Verifyuser function");
    if(req.decoded.role=="user"){
        next()
    }else{
        res.status(400).send({message:'Unauthorized'})
    }
}

const verifyAdmin = (req,res,next)=>{
    if(req.decoded.role=='admin'){
        next()
    }else{
        res.status(400).send({message:'Unauthorized'})
    }
}



userRouter.get('/oneCustomer/:id',getOneCustomer)
userRouter.get('/getCustomers',getAllCustomers)
userRouter.post('/delete/:id',deleteuser)
userRouter.post('/update/:id',updateuser)
userRouter.post('/signup',signup)
userRouter.post('/login',login)



module.exports = userRouter;