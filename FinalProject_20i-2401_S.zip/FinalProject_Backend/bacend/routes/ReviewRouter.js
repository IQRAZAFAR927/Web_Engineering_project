const ReviewRouter = require('express').Router();
// const Review = require('./reviews');
const jwt = require('jsonwebtoken')
var path = require('path')
//  const { getOneReview}  = require('../controller/ReviewController')
const  { AddReview }  = require('../controller/ReviewController')



 ReviewRouter.post('/addreview',AddReview)
// ReviewRouter.get('/getonereview', getOneReview)


module.exports= ReviewRouter;