const mongoose = require('mongoose');

// Define review schema
const reviewSchema = new mongoose.Schema({
  name:{
    required:false,
    type:String
  },
  email:{
    required:false,
    type:String
  },
  comment:{
    required:false,
    type:String
  },
  rating: {
    required:false,
    type: Number
  },
  createdAt: { type: Date, default: Date.now }
});

const Review = mongoose.model('Review', reviewSchema);
module.exports = Review;
