const mongoose = require('mongoose');

const ActivitySchema = mongoose.Schema({
    name: {
        required: true,
        type: String
    },
    description: {
        required: true,
        type: String
    },
    location: {
        required: true,
        type: String
    },
    price: {
        required: true,
        type: Number
    },
    image: {
        required: true,
        type: String
    }
});

module.exports = mongoose.model('Activity', ActivitySchema);
