import React, { useState } from 'react';
import axios from 'axios';

const AddActivity = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios.post('/listings', {
        name,
        description,
        location,
        price,
        image
      });
      alert('Activity created successfully!');
    } catch (error) {
      console.error('Error creating Activity:', error);
      alert('Failed to create Activity.');
    }
  };

  return (
    <div>
      <h2>Add Activity</h2>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        <br />
        <label>Description:</label>
        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} required />
        <br />
        <label>Location:</label>
        <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} required />
        <br />
        <label>Price:</label>
        <input type="text" value={price} onChange={(e) => setPrice(e.target.value)} required />
        <br />
        <label>Image:</label>
        <input type="text" value={image} onChange={(e) => setImage(e.target.value)} required />
        <br />
        <button type="submit">Create</button>
      </form>
    </div>
  );
};

export default AddActivity;
